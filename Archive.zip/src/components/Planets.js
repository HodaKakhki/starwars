import axios from "axios";
import React, { useEffect, useState } from "react";
import { useQuery } from "react-query";
import { Planet } from "./Planet";

const fetchPlanets = async (page) => {
  const res = await console.log(res.data);
  return res.data;
};

const Planets = () => {
  const [page, setPage] = useState(1);
  const { data, isFetching, isError } = useQuery(
    ["planet", page],
    (page) =>
      axios
        .get(`https://jsonplaceholder.typicode.com/photos/?id=${page}`)
        .then((res) => res.data),
    {
      keepPreviousData: false,
      staleTime: Infinity,
    }
  );
  useEffect(() => {
    console.log(page);
  }, [page]);

  return (
    <div>
      <h2>Planets</h2>

      {/* {status === "error" && <div>Error fetching data</div>}
      {status === "success" && (
        <>
          <button
            onClick={() => setPage((old) => Math.max(old - 1, 1))}
            disabled={page === 1}
          >
            Previouse page
          </button>
          <span>{page}</span>
          <button
            onClick={() =>
              setPage((old) =>
                !latestData || !latestData.next ? old : old + 1
              )
            }
            disabled={!latestData || !latestData.next}
          >
            Next page
          </button> */}

      <div>
        {/* {data.results.map((planet) => (
          <Planet key={planet.name} planet={planet} />
        ))} */}
      </div>
      {/* </>
      )} */}
    </div>
  );
};

export default Planets;
